-- Sweet Social Space v1 – Supabase Postgres
-- Run this entire file in Supabase SQL Editor
-- Safe to re-run

-- Profiles
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text,
  zip_code text default '95122',
  city text default 'San Jose, CA',
  bio text,
  created_at timestamptz default now()
);

alter table public.profiles enable row level security;
drop policy if exists "profiles_read_all" on public.profiles;
create policy "profiles_read_all" on public.profiles for select using (true);
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id);
drop policy if exists "profiles_insert_own" on public.profiles;
create policy "profiles_insert_own" on public.profiles for insert with check (auth.uid() = id);

-- Posts – one table for everything: neighborhood, vent, faith, alert
create table if not exists public.posts (
  id bigserial primary key,
  user_id uuid references public.profiles(id) on delete set null,
  body text not null check (char_length(body) > 0 and char_length(body) <= 2000),
  post_type text not null default 'neighborhood' check (post_type in ('neighborhood','vent','faith','alert')),
  is_anonymous boolean default false,
  zip_code text default '95122',
  city text default 'San Jose, CA',
  source_url text,
  created_at timestamptz default now()
);
create index if not exists posts_created_idx on public.posts(created_at desc);
create index if not exists posts_type_idx on public.posts(post_type);

alter table public.posts enable row level security;
drop policy if exists "posts_read_all" on public.posts;
create policy "posts_read_all" on public.posts for select using (true);
drop policy if exists "posts_insert_auth" on public.posts;
create policy "posts_insert_auth" on public.posts for insert with check (auth.uid() is not null and (user_id = auth.uid() or user_id is null));
drop policy if exists "posts_delete_own" on public.posts;
create policy "posts_delete_own" on public.posts for delete using (auth.uid() = user_id);

-- Comments
create table if not exists public.comments (
  id bigserial primary key,
  post_id bigint references public.posts(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete set null,
  body text not null check (char_length(body) > 0 and char_length(body) <= 500),
  created_at timestamptz default now()
);
alter table public.comments enable row level security;
drop policy if exists "comments_read_all" on public.comments;
create policy "comments_read_all" on public.comments for select using (true);
drop policy if exists "comments_insert_auth" on public.comments;
create policy "comments_insert_auth" on public.comments for insert with check (auth.uid() is not null);

-- Hearts / "I hear you"
create table if not exists public.hearts (
  post_id bigint references public.posts(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (post_id, user_id)
);
alter table public.hearts enable row level security;
drop policy if exists "hearts_read_all" on public.hearts;
create policy "hearts_read_all" on public.hearts for select using (true);
drop policy if exists "hearts_insert_own" on public.hearts;
create policy "hearts_insert_own" on public.hearts for insert with check (auth.uid() = user_id);
drop policy if exists "hearts_delete_own" on public.hearts;
create policy "hearts_delete_own" on public.hearts for delete using (auth.uid() = user_id);

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1)))
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Sample local alert so you can see automation working day 1
insert into public.posts (user_id, body, post_type, zip_code, city, source_url)
select null, 'Welcome to Sweet Social Space – San Jose local alerts will appear here automatically. This is a sample: Eastridge area – expect delays on Capitol Expy for roadwork.', 'alert', '95122', 'San Jose, CA', 'https://sweetsocialspace.com'
where not exists (select 1 from public.posts where post_type='alert');
