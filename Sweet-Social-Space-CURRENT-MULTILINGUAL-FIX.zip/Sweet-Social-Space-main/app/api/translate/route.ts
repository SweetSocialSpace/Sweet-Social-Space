import { NextRequest, NextResponse } from 'next/server'

const MAX_ITEMS = 100
const MAX_CHARS_PER_ITEM = 5000

function normalizeLanguage(value: unknown) {
  if (typeof value !== 'string') return ''
  return value.toLowerCase().trim().split('-')[0]
}

export async function POST(request: NextRequest) {
  try {
    // Support the primary name plus common aliases so a Vercel variable-name
    // mismatch cannot silently disable the entire translation system.
    const apiKey =
      process.env.GOOGLE_TRANSLATE_API_KEY ||
      process.env.GOOGLE_CLOUD_TRANSLATE_API_KEY ||
      process.env.GOOGLE_API_KEY

    if (!apiKey) {
      console.error('[TRANSLATE] Missing Google Translate API key.')
      return NextResponse.json(
        { error: 'Translation service is not configured.' },
        { status: 503 }
      )
    }

    const body = await request.json()
    const target = normalizeLanguage(body?.target)
    const texts = Array.isArray(body?.texts) ? body.texts : []

    if (!target || texts.length === 0 || texts.length > MAX_ITEMS) {
      return NextResponse.json(
        { error: 'Invalid translation request.' },
        { status: 400 }
      )
    }

    const cleaned = texts.map((text: unknown) =>
      typeof text === 'string' ? text.trim().slice(0, MAX_CHARS_PER_ITEM) : ''
    )

    if (cleaned.some((text: string) => !text)) {
      return NextResponse.json(
        { error: 'Translation text must be non-empty strings.' },
        { status: 400 }
      )
    }

    // English does not need a paid translation request.
    if (target === 'en') {
      return NextResponse.json({
        translations: cleaned.map(text => ({
          text,
          detectedSourceLanguage: 'en'
        }))
      })
    }

    const response = await fetch(
      `https://translation.googleapis.com/language/translate/v2?key=${encodeURIComponent(apiKey)}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          q: cleaned,
          target,
          format: 'text'
        }),
        cache: 'no-store'
      }
    )

    const payload = await response.json().catch(() => null)

    if (!response.ok) {
      const message = payload?.error?.message || `Google Translate HTTP ${response.status}`
      console.error('[TRANSLATE] Google error:', message)
      return NextResponse.json({ error: message }, { status: 502 })
    }

    const translations = payload?.data?.translations

    if (!Array.isArray(translations) || translations.length !== cleaned.length) {
      console.error('[TRANSLATE] Unexpected Google response:', payload)
      return NextResponse.json(
        { error: 'Translation response was incomplete.' },
        { status: 502 }
      )
    }

    return NextResponse.json({
      translations: translations.map((item: any) => ({
        text: item?.translatedText || '',
        detectedSourceLanguage: item?.detectedSourceLanguage || null
      }))
    })
  } catch (error) {
    console.error('[TRANSLATE] Unexpected error:', error)
    return NextResponse.json(
      { error: 'Translation service unavailable.' },
      { status: 500 }
    )
  }
}
