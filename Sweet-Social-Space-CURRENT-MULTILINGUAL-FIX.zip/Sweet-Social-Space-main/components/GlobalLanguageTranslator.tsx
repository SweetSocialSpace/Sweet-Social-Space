'use client'

import { useEffect, useRef } from 'react'
import { useLanguage } from '@/lib/language-context'
import { getGlobalTranslations } from '@/lib/translations'

const CACHE_PREFIX = 'sss_translation_v3:'
const MAX_TEXT_LENGTH = 3000
const MAX_BATCH = 80
const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'CODE', 'PRE', 'SVG'])

const originalText = new WeakMap<Text, string>()
const originalAttributes = new WeakMap<HTMLElement, Record<string, string>>()

function cacheKey(language: string, text: string) {
  return `${CACHE_PREFIX}${language}:${text}`
}

function readCache(language: string, text: string) {
  try { return sessionStorage.getItem(cacheKey(language, text)) || null } catch { return null }
}

function writeCache(language: string, text: string, translated: string) {
  try { sessionStorage.setItem(cacheKey(language, text), translated) } catch {}
}

function shouldSkip(node: Text) {
  const parent = node.parentElement
  if (!parent) return true
  if (SKIP_TAGS.has(parent.tagName)) return true
  if (parent.closest('[data-sss-no-translate]')) return true
  if (parent.closest('input, textarea, select, option')) return true
  if (!node.nodeValue?.trim()) return true
  return false
}

function collectTextNodes(root: HTMLElement) {
  const nodes: Text[] = []
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT)
  let current: Node | null

  while ((current = walker.nextNode())) {
    const node = current as Text
    if (shouldSkip(node)) continue
    if (!originalText.has(node)) originalText.set(node, node.nodeValue || '')
    const source = (originalText.get(node) || '').trim()
    if (source && source.length <= MAX_TEXT_LENGTH) nodes.push(node)
  }

  return nodes
}

function collectAttributes(root: HTMLElement) {
  return Array.from(root.querySelectorAll<HTMLElement>('[placeholder], [title], [aria-label]'))
    .filter(el => !el.closest('[data-sss-no-translate]'))
}

async function translateBatch(language: string, texts: string[]) {
  const response = await fetch('/api/translate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ target: language, texts }),
    cache: 'no-store'
  })

  const payload = await response.json().catch(() => null)
  if (!response.ok || !Array.isArray(payload?.translations)) {
    throw new Error(payload?.error || `Translation failed (${response.status})`)
  }

  return payload.translations.map((item: any) => item?.text || '')
}

function applyLocalDictionary(language: string, node: Text, source: string) {
  const dictionary = getGlobalTranslations(language)
  const exact = dictionary[source]
  if (!exact || exact === source) return false
  node.nodeValue = (originalText.get(node) || node.nodeValue || '').replace(source, exact)
  return true
}

async function translatePage(language: string, root: HTMLElement) {
  if (language === 'en') return

  const nodes = collectTextNodes(root)
  const pending = new Map<string, Text[]>()

  for (const node of nodes) {
    const source = (originalText.get(node) || '').trim()
    if (!source) continue

    // Use the platform's built-in dictionary immediately where available.
    if (applyLocalDictionary(language, node, source)) continue

    const cached = readCache(language, source)
    if (cached) {
      node.nodeValue = (originalText.get(node) || '').replace(source, cached)
      continue
    }

    const list = pending.get(source) || []
    list.push(node)
    pending.set(source, list)
  }

  const unique = Array.from(pending.keys())

  for (let i = 0; i < unique.length; i += MAX_BATCH) {
    const batch = unique.slice(i, i + MAX_BATCH)

    try {
      const translated = await translateBatch(language, batch)

      translated.forEach((value: string, index: number) => {
        const source = batch[index]
        if (!value || !source) return

        writeCache(language, source, value)

        for (const node of pending.get(source) || []) {
          if (!node.isConnected) continue
          node.nodeValue = (originalText.get(node) || '').replace(source, value)
        }
      })
    } catch (error) {
      console.error('[TRANSLATE] Page batch failed:', error)

      // Retry one item at a time. This prevents one bad string from causing
      // the entire feed to remain English.
      for (const source of batch) {
        try {
          const result = await translateBatch(language, [source])
          const value = result[0]
          if (!value) continue
          writeCache(language, source, value)
          for (const node of pending.get(source) || []) {
            if (node.isConnected) node.nodeValue = (originalText.get(node) || '').replace(source, value)
          }
        } catch {}
      }
    }
  }

  const attributes = collectAttributes(root)
  const attributeWork: Array<{ element: HTMLElement; attribute: 'placeholder'|'title'|'aria-label'; source: string }> = []

  for (const element of attributes) {
    const saved = originalAttributes.get(element) || {}
    if (!originalAttributes.has(element)) originalAttributes.set(element, saved)

    for (const attribute of ['placeholder', 'title', 'aria-label'] as const) {
      const current = element.getAttribute(attribute)
      if (!current || current.length > MAX_TEXT_LENGTH) continue
      if (!saved[attribute]) saved[attribute] = current

      const cached = readCache(language, saved[attribute])
      if (cached) element.setAttribute(attribute, cached)
      else attributeWork.push({ element, attribute, source: saved[attribute] })
    }
  }

  for (let i = 0; i < attributeWork.length; i += MAX_BATCH) {
    const batch = attributeWork.slice(i, i + MAX_BATCH)
    try {
      const translated = await translateBatch(language, batch.map(item => item.source))
      translated.forEach((value: string, index: number) => {
        const item = batch[index]
        if (!value) return
        writeCache(language, item.source, value)
        if (item.element.isConnected) item.element.setAttribute(item.attribute, value)
      })
    } catch {}
  }
}

function restoreOriginals(root: HTMLElement) {
  const nodes = collectTextNodes(root)
  for (const node of nodes) {
    const original = originalText.get(node)
    if (original !== undefined) node.nodeValue = original
  }

  for (const element of collectAttributes(root)) {
    const saved = originalAttributes.get(element)
    if (!saved) continue
    for (const attribute of ['placeholder', 'title', 'aria-label'] as const) {
      if (saved[attribute] !== undefined) element.setAttribute(attribute, saved[attribute])
    }
  }
}

export default function GlobalLanguageTranslator() {
  const { language } = useLanguage()
  const languageRef = useRef(language)

  useEffect(() => { languageRef.current = language }, [language])

  useEffect(() => {
    const root = document.body
    let timer: ReturnType<typeof setTimeout> | null = null
    let disposed = false
    let runId = 0

    const run = async () => {
      const thisRun = ++runId
      restoreOriginals(root)
      if (languageRef.current === 'en') return

      try {
        await translatePage(languageRef.current, root)
      } catch (error) {
        console.error('[TRANSLATE] Failed:', error)
      }

      if (disposed || thisRun !== runId) return
    }

    const schedule = () => {
      if (timer) clearTimeout(timer)
      timer = setTimeout(() => { void run() }, 150)
    }

    const observer = new MutationObserver(mutations => {
      // Only rerun for newly inserted UI. Text replacements performed by this
      // translator are characterData mutations and therefore do not retrigger it.
      if (mutations.some(m => m.type === 'childList' && m.addedNodes.length)) schedule()
    })

    observer.observe(root, { childList: true, subtree: true })
    void run()

    return () => {
      disposed = true
      runId++
      observer.disconnect()
      if (timer) clearTimeout(timer)
      restoreOriginals(root)
    }
  }, [language])

  return null
}
