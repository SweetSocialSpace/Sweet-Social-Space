'use client'

import { useState, useEffect } from 'react'
import { useLocation } from '@/lib/location-context'
import { useLanguage } from '@/lib/language-context'
import { useTranslations } from '@/lib/translations'

export default function WeatherBar() {
  const { zip: globalZip, city: globalCity } = useLocation()
  const { language } = useLanguage()
  const t = useTranslations()
  const zip = globalZip && globalZip !== 'YOUR_NEIGHBORHOOD' ? globalZip : ''

  const [temp, setTemp] = useState<number | null>(null)
  const [desc, setDesc] = useState('')
  const [translatedDesc, setTranslatedDesc] = useState('')
  const [city, setCity] = useState('')

  useEffect(() => {
    let cancelled = false

    const load = async () => {
      if (!zip) {
        setCity(globalCity || '')
        setDesc('')
        setTranslatedDesc('')
        setTemp(null)
        return
      }

      try {
        // Weather data is independent of UI language. This prevents changing
        // languages from breaking the actual weather lookup.
        const res = await fetch(`/api/weather?zip=${encodeURIComponent(zip)}`, { cache: 'no-store' })
        if (!res.ok) return

        const data = await res.json()
        let value = data?.temp ?? data?.main?.temp ?? null
        if (value !== null && value > 150) value = (value - 273.15) * 9 / 5 + 32

        if (cancelled) return
        setTemp(value === null ? null : Math.round(Number(value)))
        setDesc((data?.description || data?.weather?.[0]?.description || '').toLowerCase())
        setCity(data?.city || data?.name || globalCity || '')
      } catch {}
    }

    void load()
    const id = setInterval(load, 300000)
    return () => {
      cancelled = true
      clearInterval(id)
    }
  }, [zip, globalCity])

  useEffect(() => {
    let cancelled = false

    if (!desc || language === 'en') {
      setTranslatedDesc(desc)
      return
    }

    fetch('/api/translate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ target: language, texts: [desc] }),
      cache: 'no-store'
    })
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (!cancelled) setTranslatedDesc(data?.translations?.[0]?.text || desc)
      })
      .catch(() => {
        if (!cancelled) setTranslatedDesc(desc)
      })

    return () => { cancelled = true }
  }, [desc, language])

  const displayCity = city || globalCity || (zip ? zip : 'your area')

  return (
    <div className="bg-black/50 backdrop-blur-2xl rounded-2xl border border-white/10 p-4">
      <div className="flex items-center justify-between">
        <span className="text-white font-black text-xs tracking-widest">{t.weather.weather}</span>
        <span className="bg-green-500 text-black px-2 py-0.5 rounded-full font-black">{t.weather.live}</span>
      </div>
      <div className="flex items-center gap-3 mt-2">
        <div className="text-white text-3xl font-black">{temp !== null ? `${temp}°F` : '--°F'}</div>
        <span className="bg-white text-black text-xs font-black px-3 py-1 rounded-full truncate max-w-full">{displayCity}</span>
      </div>
      {translatedDesc && <div className="text-white/60 text-xs mt-2 capitalize">{translatedDesc}</div>}
    </div>
  )
}
